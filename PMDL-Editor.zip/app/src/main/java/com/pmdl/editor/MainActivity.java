package com.pmdl.editor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int OPEN = 1;
    private static final int SAVE = 2;
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private byte[] pending;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowContentAccess(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            // Solo se muestra la página incluida en la app
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                boolean image = false;
                for (String t : p.getAcceptTypes()) if (t.startsWith("image/")) image = true;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                // .pmdl no tiene tipo propio, así que se permite cualquier archivo
                i.setType(image ? "image/*" : "*/*");
                try {
                    startActivityForResult(i, OPEN);
                } catch (Exception e) {
                    chooser.onReceiveValue(null);
                    chooser = null;
                }
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class Bridge {
        @JavascriptInterface
        public void save(final String name, String base64) {
            final byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            runOnUiThread(() -> {
                pending = bytes;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/octet-stream");
                i.putExtra(Intent.EXTRA_TITLE, name);
                try {
                    startActivityForResult(i, SAVE);
                } catch (Exception e) {
                    done("error");
                }
            });
        }

        @JavascriptInterface
        public boolean copy(String text) {
            try {
                ClipboardManager c = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                c.setPrimaryClip(ClipData.newPlainText("OBJ", text));
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }

    private void done(String result) {
        pending = null;
        web.evaluateJavascript("window.onSaved('" + result + "')", null);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        Uri uri = result == RESULT_OK && data != null ? data.getData() : null;
        if (request == OPEN && chooser != null) {
            chooser.onReceiveValue(uri == null ? null : new Uri[] { uri });
            chooser = null;
        } else if (request == SAVE) {
            if (uri == null) {
                done("cancel");
            } else if (pending == null) {
                done("error");
            } else {
                // "wt" vacía el archivo antes de escribir si ya existía
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                    out.write(pending);
                    out.flush();
                } catch (Exception e) {
                    done("error");
                    return;
                }
                done("ok");
            }
        }
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setMessage("¿Salir de PMDL Editor? Se perderán los cambios sin guardar.")
                .setPositiveButton("Salir", (d, w) -> finish())
                .setNegativeButton("Cancelar", null)
                .show();
    }
}
